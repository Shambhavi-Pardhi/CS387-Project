import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faculty-page',
  templateUrl: './faculty-page.component.html',
  styleUrls: ['./faculty-page.component.css']
})
export class FacultyPageComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }


  this.yValues = [10,20,40]
  this.AvgTime = 0.03
  this.AvgAcc = yValues[1]/(yValues[0]+yValues[1])

}
